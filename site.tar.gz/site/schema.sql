-- The site's counter (functions/api/event.js): one row a day for each step of the journey, and its count.
CREATE TABLE IF NOT EXISTS events (
  day TEXT NOT NULL,
  step TEXT NOT NULL,
  n INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (day, step)
);

-- The front page's box for households (functions/api/notify.js): each address left, once, and the day it came.
CREATE TABLE IF NOT EXISTS signups (
  email TEXT PRIMARY KEY,
  day TEXT NOT NULL
);
