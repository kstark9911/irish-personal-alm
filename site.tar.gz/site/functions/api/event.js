// POST /api/event {"step": one of STEPS}: one more of that step today. The day and the step are all that is
// kept; nothing about who sent it (no address, no cookie, no identifier). Only this site's own pages are
// counted: a browser names the page's site in Origin, which a page elsewhere cannot change.
import { STEPS } from "../../lib/steps.js";

const KNOWN = new Set(STEPS);

export async function onRequestPost({ request, env }) {
  const origin = request.headers.get("Origin");
  if (!origin || origin !== new URL(request.url).origin) return new Response(null, { status: 403 });
  let step;
  try {
    ({ step } = JSON.parse(await request.text()));
  } catch {
    return new Response(null, { status: 400 });
  }
  if (!KNOWN.has(step)) return new Response(null, { status: 400 });
  const day = new Date().toISOString().slice(0, 10);
  await env.DB.prepare(
    "INSERT INTO events (day, step, n) VALUES (?1, ?2, 1) ON CONFLICT (day, step) DO UPDATE SET n = n + 1",
  ).bind(day, step).run();
  return new Response(null, { status: 204 });
}
