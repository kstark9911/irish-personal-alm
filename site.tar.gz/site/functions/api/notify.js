// POST /api/notify {"email", "hp_leave_blank"}: an address left on the front page for the one email sent when a version
// for households exists, kept once with the day it came; the private funnel page shows how many there are. Only
// this site's own page is taken (Origin, as functions/api/event.js). "hp_leave_blank" is a field a person never
// sees, named so no browser fills it: a filled one is a robot's, answered as if kept and not kept.
const ADDRESS = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function onRequestPost({ request, env }) {
  const origin = request.headers.get("Origin");
  if (!origin || origin !== new URL(request.url).origin) return new Response(null, { status: 403 });
  let body;
  try {
    body = JSON.parse(await request.text());
  } catch {
    return new Response(null, { status: 400 });
  }
  if (body && body.hp_leave_blank) return new Response(null, { status: 204 });
  const email = String((body && body.email) || "").trim().toLowerCase();
  if (email.length > 254 || !ADDRESS.test(email)) return new Response(null, { status: 400 });
  const day = new Date().toISOString().slice(0, 10);
  await env.DB.prepare("INSERT INTO signups (email, day) VALUES (?1, ?2) ON CONFLICT (email) DO NOTHING")
    .bind(email, day).run();
  return new Response(null, { status: 204 });
}
