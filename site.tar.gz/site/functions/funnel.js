// GET /funnel?key=<FUNNEL_KEY>: the private page of the journey, each step's count over the last 7 and 30 days
// and in all, how many addresses the households' box holds, and each download's count from the downloads
// repository's releases. Anyone without the key is told there is no such page.
import { STEPS } from "../lib/steps.js";
import config from "../config.json";

const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);

async function downloads(env) {
  try {
    const r = await fetch(`https://api.github.com/repos/${config.downloads_repo}/releases?per_page=20`, {
      headers: { "User-Agent": "site-funnel", Accept: "application/vnd.github+json",
                 ...(env.GITHUB_TOKEN ? { Authorization: `Bearer ${env.GITHUB_TOKEN}` } : {}) },
    });
    if (!r.ok) return null;
    return (await r.json()).flatMap(rel => (rel.assets || []).map(a => [rel.tag_name, a.name, a.download_count]));
  } catch {
    return null;
  }
}

export async function onRequestGet({ request, env }) {
  const key = new URL(request.url).searchParams.get("key");
  if (!env.FUNNEL_KEY || key !== env.FUNNEL_KEY) return new Response("Not found", { status: 404 });
  const day = n => new Date(Date.now() - n * 864e5).toISOString().slice(0, 10);
  const { results } = await env.DB.prepare(
    "SELECT step, SUM(CASE WHEN day >= ?1 THEN n ELSE 0 END) AS week, SUM(CASE WHEN day >= ?2 THEN n ELSE 0 END) AS month, " +
    "SUM(n) AS ever FROM events GROUP BY step",
  ).bind(day(6), day(29)).all();
  const by = Object.fromEntries((results || []).map(r => [r.step, r]));
  const rows = STEPS.map(s => {
    const r = by[s] || { week: 0, month: 0, ever: 0 };
    return `<tr><td>${esc(s)}</td><td>${r.week}</td><td>${r.month}</td><td>${r.ever}</td></tr>`;
  }).join("");
  const { results: left } = await env.DB.prepare("SELECT COUNT(*) AS n FROM signups").all();
  const households = (left && left[0] && left[0].n) || 0;
  const dl = await downloads(env);
  const files = dl === null ? "<p>The downloads could not be read from GitHub just now.</p>"
    : `<table><tr><th>Release</th><th>File</th><th>Downloads</th></tr>${dl.map(([t, n, c]) =>
        `<tr><td>${esc(t)}</td><td>${esc(n)}</td><td>${c}</td></tr>`).join("")}</table>`;
  const page = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="robots" content="noindex">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Funnel</title>
<style>body{font:15px/1.5 system-ui,sans-serif;margin:24px 16px;background:#f6f3ee;color:#1c1b19}
table{border-collapse:collapse;margin:8px 0 24px}td,th{border-bottom:1px solid #ddd5c8;padding:4px 14px 4px 0;text-align:left}
@media (prefers-color-scheme: dark){body{background:#1c1a17;color:#f2ede4}td,th{border-color:#3d3830}}</style></head><body>
<h1>The journey</h1><p>Each step's count, from the site's own counter: the last 7 days, the last 30, and in all.
Visits in more detail are on Cloudflare's Web Analytics page.</p>
<table><tr><th>Step</th><th>7 days</th><th>30 days</th><th>All</th></tr>${rows}</table>
<h2>Households</h2><p><span id="households">${households}</span> addresses left in the box for a version for households.</p>
<h2>Downloads</h2>${files}</body></html>`;
  return new Response(page, { headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store",
                                          "X-Robots-Tag": "noindex" } });
}
